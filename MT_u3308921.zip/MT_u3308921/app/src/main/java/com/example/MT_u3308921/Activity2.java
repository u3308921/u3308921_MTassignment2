package com.example.MT_u3308921;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
//import java.util.StringBuilder;

public class Activity2 extends AppCompatActivity {

    private static final String TAG = "Activity2";
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_STORAGE_PERMISSION = 101;

    public static final String EXTRA_READER_TYPE = "reader_type";
    public static final String EXTRA_RESULT_TEXT = "result_text";
    public static final String EXTRA_IMAGE_FILENAME = "image_filename";

    private String readerType;
    private Bitmap currentBitmap;
    private String currentFilename;
    private Uri cameraImageUri;

    private ImageView imgPreview;
    private TextView tvTitle, tvResultLabel, tvResult;
    private Button btnEditResult, btnOpenCamera, btnLoadImage;

    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            currentBitmap = ImageDecoder.decodeBitmap(
                                    ImageDecoder.createSource(getContentResolver(), cameraImageUri));
                        } else {
                            currentBitmap = MediaStore.Images.Media.getBitmap(
                                    getContentResolver(), cameraImageUri);
                        }
                        imgPreview.setImageBitmap(currentBitmap);
                        runMLKit(currentBitmap);
                    } catch (IOException e) {
                        Log.e(TAG, "Failed to decode camera image", e);
                        Toast.makeText(this, "Failed to load photo", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    private final ActivityResultLauncher<Intent> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri selectedUri = result.getData().getData();
                    if (selectedUri == null) return;
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            currentBitmap = ImageDecoder.decodeBitmap(
                                    ImageDecoder.createSource(getContentResolver(), selectedUri));
                        } else {
                            currentBitmap = MediaStore.Images.Media.getBitmap(
                                    getContentResolver(), selectedUri);
                        }
                        imgPreview.setImageBitmap(currentBitmap);
                        runMLKit(currentBitmap);
                    } catch (IOException e) {
                        Log.e(TAG, "Failed to decode gallery image", e);
                        Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        readerType = getIntent().getStringExtra(EXTRA_READER_TYPE);

        imgPreview = findViewById(R.id.imgPreview);
        tvTitle = findViewById(R.id.tvTitle);
        tvResultLabel = findViewById(R.id.tvResultLabel);
        tvResult = findViewById(R.id.tvResult);
        btnEditResult = findViewById(R.id.btnEditResult);
        btnOpenCamera = findViewById(R.id.btnOpenCamera);
        btnLoadImage = findViewById(R.id.btnLoadImage);

        // Set reader-specific image as preview placeholder
        setReaderImage();

        btnOpenCamera.setOnClickListener(v -> checkCameraPermissionAndOpen());
        btnLoadImage.setOnClickListener(v -> checkStoragePermissionAndOpen());

        btnEditResult.setOnClickListener(v -> {
            if (currentBitmap == null || currentFilename == null) return;
            Intent intent = new Intent(this, Activity5.class);
            intent.putExtra(Activity5.EXTRA_READER_TYPE, readerType);
            intent.putExtra(Activity5.EXTRA_RESULT_TEXT, tvResult.getText().toString());
            intent.putExtra(Activity5.EXTRA_IMAGE_FILENAME, currentFilename);
            startActivity(intent);
        });
    }

    private void setReaderImage() {
        if (readerType == null) return;
        tvTitle.setText(readerType);
        switch (readerType) {
            case Activity1.READER_BARCODE:
                imgPreview.setImageResource(R.mipmap.barcode);
                break;
            case Activity1.READER_CONTENT:
                imgPreview.setImageResource(R.mipmap.content);
                break;
            case Activity1.READER_TEXT:
                imgPreview.setImageResource(R.mipmap.text);
                break;
        }
    }

    private void checkCameraPermissionAndOpen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePicture.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "No camera app found", Toast.LENGTH_SHORT).show();
            return;
        }
        File photoFile = createImageFile();
        if (photoFile == null) return;
        cameraImageUri = FileProvider.getUriForFile(this,
                getApplicationContext().getPackageName() + ".fileprovider", photoFile);
        takePicture.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
        cameraLauncher.launch(takePicture);
    }

    private File createImageFile() {
        currentFilename = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.US).format(new Date());
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        try {
            return File.createTempFile(currentFilename, ".jpg", storageDir);
        } catch (IOException e) {
            Log.e(TAG, "Failed to create image file", e);
            return null;
        }
    }

    private void checkStoragePermissionAndOpen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQUEST_STORAGE_PERMISSION);
            } else {
                openGallery();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
            } else {
                openGallery();
            }
        }
    }

    private void openGallery() {
        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickPhoto.setType("image/*");
        galleryLauncher.launch(pickPhoto);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == REQUEST_CAMERA_PERMISSION) openCamera();
            else if (requestCode == REQUEST_STORAGE_PERMISSION) openGallery();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    private void runMLKit(Bitmap bitmap) {
        // Generate a filename if we don't have one yet (gallery case)
        if (currentFilename == null) {
            currentFilename = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.US).format(new Date());
        }

        // Save image to internal storage
        ImageStorageHelper.saveBitmap(this, bitmap, currentFilename);

        InputImage image = InputImage.fromBitmap(bitmap, 0);
        tvResult.setText("Analysing");
        tvResultLabel.setText("");
        btnEditResult.setVisibility(View.GONE);

        if (readerType == null) return;

        switch (readerType) {
            case Activity1.READER_BARCODE:
                runBarcodeReader(image);
                break;
            case Activity1.READER_CONTENT:
                runContentReader(image);
                break;
            case Activity1.READER_TEXT:
                runTextReader(image);
                break;
        }
    }

    private void runBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                .build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    if (barcodes.isEmpty()) {
                        showResult("Detected barcode:", "No barcode detected.");
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    for (Barcode barcode : barcodes) {
                        String raw = barcode.getRawValue();
                        if (raw != null) sb.append(raw).append("; ");
                    }
                    showResult("Detected barcode:", sb.toString().trim());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Barcode scan failed", e);
                    showResult("Detected barcode:", "Error: " + e.getMessage());
                });
    }

    private void runContentReader(InputImage image) {
        ImageLabelerOptions options = new ImageLabelerOptions.Builder()
                .setConfidenceThreshold(0.60f)
                .build();
        ImageLabeler labeler = ImageLabeling.getClient(options);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        showResult("Recognised image content:", "No labels detected.");
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    int i = 1;
                    for (ImageLabel label : labels) {
                        sb.append(i++).append(". ")
                                .append(label.getText())
                                .append(": (")
                                .append(String.format(Locale.US, "%.0f", label.getConfidence() * 100))
                                .append("% confidence)\n");
                    }
                    showResult("Recognised image content:", sb.toString().trim());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Image labelling failed", e);
                    showResult("Recognised image content:", "Error: " + e.getMessage());
                });
    }

    private void runTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    String extracted = visionText.getText().trim();
                    if (extracted.isEmpty()) extracted = "No text detected.";
                    showResult("Extracted text:", extracted);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Text recognition failed", e);
                    showResult("Extracted text:", "Error: " + e.getMessage());
                });
    }

    private void showResult(String label, String result) {
        tvResultLabel.setText(label);
        tvResult.setText(result);
        btnEditResult.setVisibility(View.VISIBLE);
    }
}
