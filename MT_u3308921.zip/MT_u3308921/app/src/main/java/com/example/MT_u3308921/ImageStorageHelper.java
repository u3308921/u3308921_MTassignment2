package com.example.MT_u3308921;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ImageStorageHelper {

    private static final String TAG = "ImageStorageHelper";
    private static final String IMAGE_DIR = "images";

    /**
     * Saves a bitmap to internal storage using the given filename.
     * Returns true on success.
     */
    public static boolean saveBitmap(Context context, Bitmap bitmap, String filename) {
        File dir = new File(context.getFilesDir(), IMAGE_DIR);
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, filename + ".jpg");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Failed to save bitmap", e);
            return false;
        }
    }

    /**
     * Saves an image from a Uri to internal storage.
     * Returns the filename (without extension) on success, null on failure.
     */
    public static String saveFromUri(Context context, Uri uri, String filename) {
        File dir = new File(context.getFilesDir(), IMAGE_DIR);
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, filename + ".jpg");
        try (InputStream in = context.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(file)) {
            if (in == null) return null;
            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
            return filename;
        } catch (IOException e) {
            Log.e(TAG, "Failed to save from uri", e);
            return null;
        }
    }

    /**
     * Loads a bitmap from internal storage by filename.
     * Returns null if not found.
     */
    public static Bitmap loadBitmap(Context context, String filename) {
        File dir = new File(context.getFilesDir(), IMAGE_DIR);
        File file = new File(dir, filename + ".jpg");
        if (!file.exists()) return null;
        try (FileInputStream fis = new FileInputStream(file)) {
            return BitmapFactory.decodeStream(fis);
        } catch (IOException e) {
            Log.e(TAG, "Failed to load bitmap", e);
            return null;
        }
    }

    /**
     * Deletes an image file from internal storage.
     */
    public static boolean deleteImage(Context context, String filename) {
        File dir = new File(context.getFilesDir(), IMAGE_DIR);
        File file = new File(dir, filename + ".jpg");
        return file.exists() && file.delete();
    }

    /**
     * Returns the File for a given filename (for FileProvider if needed).
     */
    public static File getImageFile(Context context, String filename) {
        File dir = new File(context.getFilesDir(), IMAGE_DIR);
        return new File(dir, filename + ".jpg");
    }
}
