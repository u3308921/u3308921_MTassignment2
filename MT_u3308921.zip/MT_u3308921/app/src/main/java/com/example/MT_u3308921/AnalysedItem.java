package com.example.MT_u3308921;

public class AnalysedItem {
    private String key;        // Firebase key
    private String filename;   // image filename stored on device
    private String reader;     // reader type label
    private String text;       // ML Kit result text

    public AnalysedItem() {
        // Required for Firebase
    }

    public AnalysedItem(String filename, String reader, String text) {
        this.filename = filename;
        this.reader = reader;
        this.text = text;
    }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public String getFilename() { return filename; }
    public void setFilename(String filename) { this.filename = filename; }

    public String getReader() { return reader; }
    public void setReader(String reader) { this.reader = reader; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
}
