# Add project specific ProGuard rules here.
-keep class com.example.MT_u3308921.** { *; }
-keep class com.google.mlkit.** { *; }
-keep class com.google.firebase.** { *; }
