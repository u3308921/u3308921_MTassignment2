# MLKit App — Setup Instructions

## Step 1: Create a Firebase Project

1. Go to https://console.firebase.google.com
2. Click **Add project** → name it (e.g. `MLKitApp`) → Continue
3. Disable Google Analytics if not needed → **Create project**

## Step 2: Add Android App to Firebase

1. In your Firebase project, click the **Android** icon
2. Enter package name: `com.example.mlkitapp`
3. Enter app nickname: `MLKit App` (optional)
4. Click **Register app**
5. **Download `google-services.json`**
6. **Replace** the placeholder `app/google-services.json` with your downloaded file

## Step 3: Enable Firebase Realtime Database

1. In Firebase Console → **Build** → **Realtime Database**
2. Click **Create Database**
3. Choose your region → **Next**
4. Select **Start in test mode** → **Enable**
   - (Test mode allows read/write for 30 days — secure before going live)

## Step 4: Open Project in Android Studio

1. Open Android Studio → **Open** → select the `MLKitApp` folder
2. Wait for Gradle sync to complete
3. Make sure your `google-services.json` is in the `app/` folder
4. Connect your Android device (API 24+) or start an emulator (VanillaIceCream API 35)
5. Click **Run ▶**

## Step 5: Enable Camera on Emulator (if using emulator)

- In Android Studio AVD Manager → Edit your emulator → **Advanced Settings**
- Set **Front/Back Camera** to **Webcam** or **VirtualScene**

## Firebase Database Rules (for production)

```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

## Project Structure

```
app/
├── java/com/example/mlkitapp/
│   ├── Activity1.java      ← Home: 3 reader buttons + list button
│   ├── Activity2.java      ← Camera/gallery + ML Kit analysis
│   ├── Activity5.java      ← Edit text + save to Firebase
│   ├── Activity6.java      ← List view (loads from Firebase)
│   ├── Activity7.java      ← Detail view (Edit/Delete/Cancel)
│   ├── AnalysedItem.java   ← Data model
│   ├── ListAdapter.java    ← Custom ListView adapter
│   └── ImageStorageHelper.java ← Save/load images from internal storage
├── res/
│   ├── layout/
│   │   ├── activity_1.xml
│   │   ├── activity_2.xml
│   │   ├── activity_5.xml
│   │   ├── activity_6.xml
│   │   ├── activity_7.xml
│   │   └── list_item.xml
│   ├── drawable/ (icons + placeholder)
│   └── values/ (strings, colors, themes)
└── AndroidManifest.xml
```

## Notes

- Activities 3 and 4 are Android's **built-in** camera and gallery intents — no extra code needed
- Images are saved to **internal storage** (`files/images/`) using the filename as a key
- Firebase stores: `filename`, `reader` (type), and `text` (ML Kit result)
- ML Kit runs **on-device** — no internet needed for analysis itself (only Firebase needs internet)
