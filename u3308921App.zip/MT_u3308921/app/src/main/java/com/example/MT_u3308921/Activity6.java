package com.example.MT_u3308921;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mt2026_groupproject.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {

    private ListAdapter listAdapter;
    private final List<AnalysedItem> itemList = new ArrayList<>();
    private DatabaseReference dbRef;
    private ValueEventListener firebaseListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);

        ListView listView = findViewById(R.id.listView);
        Button btnAdd     = findViewById(R.id.btnAdd);

        listAdapter = new ListAdapter(this, itemList);
        listView.setAdapter(listAdapter);

        dbRef = FirebaseDatabase.getInstance().getReference("Storage");

        // Tap item → Activity 7
        listView.setOnItemClickListener((parent, view, position, id) -> {
            AnalysedItem item = itemList.get(position);
            Intent intent = new Intent(this, Activity7.class);
            intent.putExtra(Activity7.EXTRA_FIREBASE_KEY,    item.getKey());
            intent.putExtra(Activity7.EXTRA_READER_TYPE,     item.getReader());
            intent.putExtra(Activity7.EXTRA_RESULT_TEXT,     item.getText());
            intent.putExtra(Activity7.EXTRA_IMAGE_FILENAME,  item.getFilename());
            startActivity(intent);
        });

        // Add → Activity 1
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity1.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFromFirebase();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (firebaseListener != null) dbRef.removeEventListener(firebaseListener);
    }

    private void loadFromFirebase() {
        firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                itemList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    AnalysedItem item = new AnalysedItem();
                    item.setKey(child.getKey());
                    if (child.hasChild("filename"))
                        item.setFilename(child.child("filename").getValue(String.class));
                    if (child.hasChild("reader"))
                        item.setReader(child.child("reader").getValue(String.class));
                    if (child.hasChild("text"))
                        item.setText(child.child("text").getValue(String.class));
                    itemList.add(item);
                }
                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Activity6.this,
                        "Failed to load data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        dbRef.addValueEventListener(firebaseListener);
    }
}
