package com.example.MT_u3308921;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mt2026_groupproject.R;
import com.google.firebase.database.FirebaseDatabase;

public class Activity7 extends AppCompatActivity {

    public static final String EXTRA_FIREBASE_KEY   = "firebase_key";
    public static final String EXTRA_READER_TYPE    = "reader_type";
    public static final String EXTRA_RESULT_TEXT    = "result_text";
    public static final String EXTRA_IMAGE_FILENAME = "image_filename";

    private String firebaseKey;
    private String readerType;
    private String resultText;
    private String imageFilename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);

        firebaseKey   = getIntent().getStringExtra(EXTRA_FIREBASE_KEY);
        readerType    = getIntent().getStringExtra(EXTRA_READER_TYPE);
        resultText    = getIntent().getStringExtra(EXTRA_RESULT_TEXT);
        imageFilename = getIntent().getStringExtra(EXTRA_IMAGE_FILENAME);

        TextView tvReaderName  = findViewById(R.id.tvReaderName);
        TextView tvResultLabel = findViewById(R.id.tvResultLabel);
        TextView tvResult      = findViewById(R.id.tvResult);
        ImageView imgPreview   = findViewById(R.id.imgPreview);
        Button btnEdit         = findViewById(R.id.btnEdit);
        Button btnDelete       = findViewById(R.id.btnDelete);
        Button btnCancel       = findViewById(R.id.btnCancel);

        // Populate UI
        if (readerType != null) tvReaderName.setText(readerType);
        if (resultText != null) tvResult.setText(resultText);

        // Set label based on reader type
        if (readerType != null) {
            switch (readerType) {
                case Activity1.READER_BARCODE:
                    tvResultLabel.setText("Detected barcode:");
                    break;
                case Activity1.READER_CONTENT:
                    tvResultLabel.setText("Recognised image content:");
                    break;
                case Activity1.READER_TEXT:
                    tvResultLabel.setText("Extracted text:");
                    break;
            }
        }

        // Load image from internal storage
        if (imageFilename != null) {
            Bitmap bmp = ImageStorageHelper.loadBitmap(this, imageFilename);
            if (bmp != null) imgPreview.setImageBitmap(bmp);
            else imgPreview.setImageResource(R.drawable.ic_placeholder);
        }

        // Edit → Activity 5
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            intent.putExtra(Activity5.EXTRA_READER_TYPE,    readerType);
            intent.putExtra(Activity5.EXTRA_RESULT_TEXT,    resultText);
            intent.putExtra(Activity5.EXTRA_IMAGE_FILENAME, imageFilename);
            intent.putExtra(Activity5.EXTRA_FIREBASE_KEY,   firebaseKey);
            startActivity(intent);
            finish();
        });

        // Delete → remove from Firebase then go to Activity 6
        btnDelete.setOnClickListener(v -> deleteItem());

        // Cancel → go back to Activity 6 unchanged
        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }

    private void deleteItem() {
        if (firebaseKey == null) {
            Toast.makeText(this, "Cannot delete: missing key", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseDatabase.getInstance().getReference("Storage")
                .child(firebaseKey)
                .removeValue()
                .addOnSuccessListener(unused -> {
                    // Also delete local image file
                    if (imageFilename != null) {
                        ImageStorageHelper.deleteImage(this, imageFilename);
                    }
                    Toast.makeText(this, "Deleted successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, Activity6.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Delete failed: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }
}
