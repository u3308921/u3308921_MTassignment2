package com.example.MT_u3308921;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.mt2026_groupproject.R;

import java.util.List;

public class ListAdapter extends ArrayAdapter<AnalysedItem> {

    private final Context context;
    private final List<AnalysedItem> items;

    public ListAdapter(Context context, List<AnalysedItem> items) {
        super(context, R.layout.list_item, items);
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
            holder = new ViewHolder();
            holder.imgThumb  = convertView.findViewById(R.id.imgThumb);
            holder.tvName    = convertView.findViewById(R.id.tvItemName);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        AnalysedItem item = items.get(position);

        // Show reader name as the list label
        holder.tvName.setText(item.getReader() != null ? item.getReader() : "");

        // Load thumbnail from internal storage
        holder.imgThumb.setImageResource(R.drawable.ic_placeholder);
        if (item.getFilename() != null) {
            Bitmap bmp = ImageStorageHelper.loadBitmap(context, item.getFilename());
            if (bmp != null) holder.imgThumb.setImageBitmap(bmp);
        }

        return convertView;
    }

    static class ViewHolder {
        ImageView imgThumb;
        TextView tvName;
    }
}
