package com.example.MT_u3308921;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mt2026_groupproject.R;

public class Activity1 extends AppCompatActivity {

    public static final String EXTRA_READER_TYPE = "reader_type";
    public static final String READER_BARCODE = "Barcode Reader";
    public static final String READER_CONTENT = "Content Reader";
    public static final String READER_TEXT = "Text Reader";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);

        ImageButton btnBarcode = findViewById(R.id.buttonBarcode);
        ImageButton btnContent = findViewById(R.id.buttonContent);
        ImageButton btnText = findViewById(R.id.buttonText);
        Button btnList = findViewById(R.id.btnList);

        btnBarcode.setOnClickListener(v -> openActivity2(READER_BARCODE));
        btnContent.setOnClickListener(v -> openActivity2(READER_CONTENT));
        btnText.setOnClickListener(v -> openActivity2(READER_TEXT));

        btnList.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            startActivity(intent);
        });
    }

    private void openActivity2(String readerType) {
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra(EXTRA_READER_TYPE, readerType);
        startActivity(intent);
    }
}
