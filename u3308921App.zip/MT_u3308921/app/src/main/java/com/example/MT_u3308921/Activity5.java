package com.example.MT_u3308921;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mt2026_groupproject.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Activity5 extends AppCompatActivity {

    public static final String EXTRA_READER_TYPE   = "reader_type";
    public static final String EXTRA_RESULT_TEXT   = "result_text";
    public static final String EXTRA_IMAGE_FILENAME = "image_filename";
    public static final String EXTRA_FIREBASE_KEY  = "firebase_key";  // present when editing existing item

    private String readerType;
    private String imageFilename;
    private String firebaseKey;   // null when creating new, non-null when editing

    private ImageView imgPreview;
    private EditText etResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);

        readerType    = getIntent().getStringExtra(EXTRA_READER_TYPE);
        imageFilename = getIntent().getStringExtra(EXTRA_IMAGE_FILENAME);
        String resultText = getIntent().getStringExtra(EXTRA_RESULT_TEXT);
        firebaseKey   = getIntent().getStringExtra(EXTRA_FIREBASE_KEY);

        TextView tvReaderName = findViewById(R.id.tvReaderName);
        imgPreview            = findViewById(R.id.imgPreview);
        etResult              = findViewById(R.id.etResult);
        Button btnSave        = findViewById(R.id.btnSave);

        if (readerType != null) tvReaderName.setText(readerType);
        if (resultText != null) etResult.setText(resultText);

        loadImage();

        btnSave.setOnClickListener(v -> saveToFirebase());
    }

    private void loadImage() {
        if (imageFilename == null) return;
        Bitmap bmp = ImageStorageHelper.loadBitmap(this, imageFilename);
        if (bmp != null) imgPreview.setImageBitmap(bmp);
    }

    private void saveToFirebase() {
        String editedText = etResult.getText().toString().trim();
        if (editedText.isEmpty()) {
            Toast.makeText(this, "Result text cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        String key = (firebaseKey != null && !firebaseKey.isEmpty())
                ? firebaseKey
                : new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.US).format(new Date());

        if (imageFilename == null) imageFilename = key;

        Bitmap bmp = ImageStorageHelper.loadBitmap(this, imageFilename);
        if (bmp == null) {
            Toast.makeText(this, "Image not found", Toast.LENGTH_SHORT).show();
            return;
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 90, baos);
        byte[] imageData = baos.toByteArray();

        StorageReference storageRef = FirebaseStorage.getInstance()
                .getReference("images/" + imageFilename + ".jpg");

        String finalKey = key;
        storageRef.putBytes(imageData)
                .addOnSuccessListener(taskSnapshot -> {
                    // Now save metadata to Realtime Database
                    DatabaseReference db = FirebaseDatabase.getInstance().getReference("Storage");
                    Map<String, Object> data = new HashMap<>();
                    data.put("filename", imageFilename);
                    data.put("reader", readerType != null ? readerType : "");
                    data.put("text", editedText);

                    db.child(finalKey).setValue(data)
                            .addOnSuccessListener(unused -> {
                                Toast.makeText(this, "Saved successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(this, Activity6.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                startActivity(intent);
                                finish();
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Metadata save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Image upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}
